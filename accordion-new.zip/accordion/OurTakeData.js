let totalItems = document.getElementsByClassName("accord_main-list")
let totalItemsLength = Array.from(document.getElementsByClassName("accord_main-list"))?.length
let viewItems = 2
let increValue = 5

function updateItems(){
    for (let index = 0; index < viewItems; index++) {
        totalItems[index].classList.add("show")
        console.log(totalItems[index])
    }
    if(viewItems+increValue < totalItemsLength){
        viewItems += increValue
    }else{
        viewItems = totalItemsLength
    }
}

updateItems();




